import React from 'react';

function CONT_CAMEL_NAME() {
    return <div />;
}

export default CONT_CAMEL_NAME;