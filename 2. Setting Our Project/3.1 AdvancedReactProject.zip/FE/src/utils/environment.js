let BASE_URL = 'http://localhost:9000/';

export {BASE_URL};
