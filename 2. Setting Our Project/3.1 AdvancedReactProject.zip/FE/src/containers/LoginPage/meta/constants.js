/*
 *
 * LoginPage constants
 *
 */

export const DEFAULT_ACTION = 'app/LoginPage/DEFAULT_ACTION';
export const LOGIN_FIELD_CHANGE = 'app/LoginPage/LOGIN_FIELD_CHANGE';
