import { master } from './master';
import { password } from './password';
export { password, master };
