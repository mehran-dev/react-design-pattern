
const NewComponent1 = withRouter(Component1);


const NewComponent2 = connect(mapStateToProps, mapDispatch)(Component2);








































NewComponent2()
NewComponent1()
