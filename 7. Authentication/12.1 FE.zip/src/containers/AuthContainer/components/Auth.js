import React from 'react';

function Auth() {
    return <div />;
}

export default Auth;