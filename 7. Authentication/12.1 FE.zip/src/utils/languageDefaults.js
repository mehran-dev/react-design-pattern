export const DEFAULT_LOCALE = 'en';

export const localeData = {
  en: {
    fontFamily: 'Ubuntu',
    direction: 'ltr',
  },
};
